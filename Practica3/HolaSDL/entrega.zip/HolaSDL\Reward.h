#pragma once
#include "SceneObject.h"
class Reward : public SceneObject
{
public:
	Reward() = default;
};

